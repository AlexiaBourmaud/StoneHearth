package test;

import static org.junit.Assert.*;

import org.junit.Test;

import factory.ComposantFactory;
import Interface.ICarte;
import Interface.IInfoCompte;
import Interface.IListeDeCartes;

public class TestAppli {

	@Test
	public void test() {
	
		/**IInfoCompte ic = ComposantFactory.createInfoCompte();
		ic.setIsConnected(true);
		
		IListeDeCartes coll = ComposantFactory.createCollection();
		
		ICarte dico =  ComposantFactory.createDico();
		
		for (String c : coll.listerCartesListe("toto", "coll")) {
			System.out.println(dico.infosCarte(c));
		}*/
	}

}
