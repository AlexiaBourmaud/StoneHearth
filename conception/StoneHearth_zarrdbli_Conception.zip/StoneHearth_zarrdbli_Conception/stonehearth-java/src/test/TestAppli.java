package test;

import static org.junit.Assert.*;

import java.util.Set;

import org.junit.Test;

import factory.ComposantFactory;
import Interface.ICarte;
import Interface.IInfoCompte;
import Interface.IInfoJoueur;
import Interface.IListeDeCartes;
import Interface.IPaiement;

public class TestAppli {
	/*
		@Test
		public void test() {
		
			/**IInfoCompte ic = ComposantFactory.createInfoCompte();
			ic.setIsConnected(true);
			
			IListeDeCartes coll = ComposantFactory.createCollection();
			
			ICarte dico =  ComposantFactory.createDico();
			
			for (String c : coll.listerCartesListe("toto", "coll")) {
				System.out.println(dico.infosCarte(c));
			}
		}
	*/

	@Test
	public void testAcheterCarte() {
	    //ligne de vie
		IPaiement ip = ComposantFactory.createCPaiement();
		ICarte iCarte = ComposantFactory.createCCarte();
		
		String[] listeCarte = iCarte.listerCartes();
		System.out.println(listeCarte);
		String nomCarte = listeCarte[3];
		String info = iCarte.infosCarte(nomCarte);
		System.out.println("Information de la carte : "+info);
		
		IInfoJoueur iInfoJoueur = ComposantFactory.createCInfoJoueur(ip, iCarte);
		Integer soldeRestant = iInfoJoueur.acheterCarte(nomCarte);
		Integer prix = iCarte.getPrixAchat(nomCarte);
		System.out.println("Prix de l'achat : "+prix);
		System.out.println("Solde restant : "+soldeRestant);
	}
	
	
	@Test
	public void testAcheterEmplacementDeckPack() {
	    // Initialisation des lignes de vies
	    IInfoCompte infoCompte = ComposantFactory.createCInfoCompte();
	    IPaiement paiement = ComposantFactory.createCPaiement();
	    IInfoJoueur infoJoueur = ComposantFactory.createCInfoJoueur(paiement, null); //car pas de carte requise dans le diagramme de séquence
	
	    infoCompte.acheterEmplacementDeckPack();
	}
	
	
	@Test
	public void testAjouterCoordonneesBancaires() {
	
	}
	
	
	@Test
	public void testComposerDeck() {
	//ligne de vie
	IPaiement ip = ComposantFactory.createCPaiement();
	ICarte iCarte = ComposantFactory.createCCarte();
	IInfoJoueur iInfoJoueur = ComposantFactory.createCInfoJoueur(ip, iCarte);
	IListeDeCartes coll = ComposantFactory.createCListeDeCarte();
		
	for (String d : iInfoJoueur.listerDeckJoueur("Bob")) {
		System.out.println(d);
	}
	// le joueur choisit le deck D1
	for (String c : coll.listerCartesListe("Bob", "D1")) {
		System.out.println(c);
	}
		
	String collection = iInfoJoueur.getCollection("Bob");
	for (String c : coll.listerCartesListe("Bob", "collection")) {
		System.out.println(c);
	}
		
	//le joueur clique sur la carte chat
	System.out.println(iCarte.infosCarte("chat"));
	
	Boolean vide= coll.verificationDeckEmplacementVide("Bob","D1");
	if (vide) {
		for(String c : coll.ajouterCarteListe("Bob", "chat", "D1")){
			System.out.println(c);
		}
	}
	else System.out.println("Vous n'avez plus de place dans votre deck.");
	
	}
	
	
	@Test
	public void testDetruireCarte() {
	//ligne de vie
	IPaiement ip = ComposantFactory.createCPaiement();
	ICarte iCarte = ComposantFactory.createCCarte();
	IInfoJoueur iInfoJoueur = ComposantFactory.createCInfoJoueur(ip, iCarte);
	IListeDeCartes coll = ComposantFactory.createCListeDeCarte();
		
	String collection = iInfoJoueur.getCollection("Bob");
		
	for (String c : coll.listerCartesListe("Bob", collection)) {
		if( iCarte.getPrixVente(c) != 0 )
		System.out.println(c);
	}
	//le joueur clique sur la carte chat
	System.out.println(iCarte.infosCarte("chat"));
	int prix=iCarte.getPrixVente("chat");
	
	System.out.println(prix);
		
	Set<String> retour = iInfoJoueur.destructionCarte("Bob","chat");
	if (retour.contains("true")){
		System.out.println("La destruction a été réalisée avec succès.");
		Object[] res= retour.toArray();
		System.out.println("Votre nouveau solde est de "+res[0]+" joyaux");
	}
	else System.out.println("La destruction n'a pas fonctionnée");
	
	
	}
	
	
	@Test
	public void testInscription() {
	
	}
	
	
	@Test
	public void testJouer() {
	
	}
	
	
	@Test
	public void testSeConnecter() {
	    String pseudo = "Cedric23";
	    String motDePasse = "soleil";
	
	    // Initialisation des lignes de vies
	    IInfoCompte infoCompte = ComposantFactory.createCInfoCompte();
	
	    if (infoCompte.verifierPseudoMotDePasse(pseudo, motDePasse)) {
	        if (!(infoCompte.getIsConnected())) {
	            infoCompte.setIsConnected(true);
	        }
	    }
	}
	
	
	@Test
	public void testSeDeconnecter() {
	
	    // Initialisation des lignes de vies
	    IInfoCompte infoCompte = ComposantFactory.createCInfoCompte();
	
	    if (infoCompte.getIsConnected()) {
	        infoCompte.setIsConnected(false);
	    }
	}
	
	
	@Test
	public void testOuvrirPack() {
	
	    // Initialisation des lignes de vies
	    IInfoCompte infoCompte = ComposantFactory.createCInfoCompte();
	    IInfoJoueur infoJoueur = ComposantFactory.createCInfoJoueur(null, null);
	
	    if (infoJoueur.getNumberOfPacks() > 0) {
	        // TODO: Ouvrir le pack
	    }
	}
}