package Joueur;

import java.util.Date;

import Interface.IInfoCompte;

public class GestCompte implements IInfoCompte {

	@Override
	public Boolean estConnecte(String idJoueur, String mdp) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public void acheterEmplacementDeckPack() {
		// TODO Module de remplacement de méthode auto-généré

	}

	@Override
	public Boolean enregistrerCB(String nom, Integer numero,
			Date dateExpiration, String cvv) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean enregistrerDonnees(String pseudo, String motDePasse) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public String getCoordonneesBancaires(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean verifierPseudoMotDePasse(String idJoueur, String pass) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean setIsConnected(Boolean val) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean getIsConnected() {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean disponiblePseudo(String pseudo) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

}
