package Bouchons;

import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

import Interface.IInfoCompte;
import Interface.IInfoJoueur;

public class GestJoueurBouchon implements IInfoJoueur, IInfoCompte{

	@Override
	public Boolean estConnecte(String idJoueur, String mdp) {
		return true;
	}

	@Override
	public void acheterEmplacementDeckPack() {
		// TODO Module de remplacement de méthode auto-généré
		
	}

	@Override
	public Boolean enregistrerCB(String nom, Integer numero,
			Date dateExpiration, String cvv) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean enregistrerDonnees(String pseudo, String motDePasse) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public String getCoordonneesBancaires(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean verifierPseudoMotDePasse(String idJoueur, String pass) {
		return true;
	}

	@Override
	public Boolean setIsConnected(Boolean val) {
		return true;
	}

	@Override
	public Boolean getIsConnected() {
		return true;
	}

	@Override
	public Boolean disponiblePseudo(String pseudo) {
		return true;
	}

	@Override
	public Set<String> listerDeckJoueur(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public int majSoldejoyaux(String idJoueur, String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return 0;
	}

	@Override
	public Set<String> ajouterCarteCollection(String idJoueur, String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public ArrayList<String> destructionCarte(String idJoueur, String nomCarte) {
		ArrayList<String> res = new ArrayList<String>();
		res.add("39");
		res.add("true");
		return res;
	}

	@Override
	public void donnerPack(String id) {
		// TODO Module de remplacement de méthode auto-généré
		
	}

	@Override
	public Boolean VerificationAttributionPack(String id) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean verifierSoldeJoyaux(String idJoueur, String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Integer acheterCarte(String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return 20;
	}

	@Override
	public Integer getRang(String idJoueur) {
		return 10;
	}

	@Override
	public ArrayList<String> getCollection(String idJoueur) {
		ArrayList<String> res = new ArrayList<String>();
		res.add("chat");
		res.add("Robert");
		return res;
	}

	@Override
	public Boolean actualiserRang(String idJoueur, Boolean aGagne) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public int getNumberOfPacks() {
		return 5;
	}

	@Override
	public String[] ouvrirPack() {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public int getNb_joyaux() {
		return 37;
	}

	@Override
	public String getName() {
		return "Bob";
	}

}
