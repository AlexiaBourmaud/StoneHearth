package Bouchons;

import java.util.ArrayList;
import java.util.Arrays;

import Carte.Carte;
import Carte.GestCarte;
import Carte.RareteCarte;
import Interface.ICarte;

// le prof propose un truc tout simple 
/* 
 *public class CarteBOuchon implements ICarte  '
 * public CarteBouchon(){ }
 * 
 *
 */

public class CarteBouchon implements ICarte {


	private GestCarte gest;
	
	public CarteBouchon(){
//		gest = new GestCarte(new ArrayList<String>(Arrays.asList("Voleuse solitaire")), 
//				new ArrayList<Integer>(Arrays.asList(30)), 
//				new ArrayList<Integer>(Arrays.asList(20)), 
//				new ArrayList<String>(Arrays.asList("Une voleuse vagabonde voyageant de ville en ville, volant pour survivre. Méfiez-vous de sa dague tranchante.")),
//				new ArrayList<RareteCarte>(Arrays.asList(RareteCarte.commune)));
	}

	public ArrayList<Carte> infosCarte(ArrayList<String> nomCartes) {
		return gest.infosCarte(nomCartes);
	}

	@Override
	public ArrayList<String> listerCartes() {
		return gest.listerCartes();
	}

	@Override
	public ArrayList<RareteCarte> rareteCarte(ArrayList<String> nomCartes) {
		return gest.rareteCarte(nomCartes);
	}

	@Override
	public ArrayList<Integer> getPrixVente(ArrayList<String> nomCartes) {
		return gest.getPrixVente(nomCartes);
	}

	@Override
	public Integer getPrixAchat(String nomCarte) {
		return 20;
	}

	@Override
	public Integer getPrixVente(String nomCarte) {
		return 2;
	}

	@Override
	public ArrayList<Integer> getPrixAchat(ArrayList<String> nomCartes) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public String getNomCarte() {
		return "Voleuse solitaire";
	}
}
