package Bouchons;

public class PaiementBouchon {
	public Boolean payer(String cb, Float montant) {
		return true;
	}
}
