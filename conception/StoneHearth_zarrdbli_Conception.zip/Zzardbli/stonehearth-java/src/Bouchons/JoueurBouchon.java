package Bouchons;

import java.util.Set;

import Interface.IInfoJoueur;

public class JoueurBouchon implements IInfoJoueur {

	@Override
	public Set<String> listerDeckJoueur(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public int majSoldejoyaux(String idJoueur, String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return 0;
	}

	@Override
	public Set<String> ajouterCarteCollection(String idJoueur, String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Set<String> destructionCarte(String idJoueur, String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public void donnerPack(String id) {
		// TODO Module de remplacement de méthode auto-généré
		
	}

	@Override
	public Boolean VerificationAttributionPack(String id) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean verifierSoldeJoyaux(String idJoueur, String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Integer acheterCarte(String nomCarte) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Integer getRang(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public String getCollection(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean actualiserRang(String idJoueur, Boolean aGagne) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public void incrementerCompteurPacks(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		
	}

	@Override
	public int getNumberOfPacks() {
		// TODO Module de remplacement de méthode auto-généré
		return 0;
	}

}
