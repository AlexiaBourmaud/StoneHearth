package test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;

import org.junit.Test;

import factory.ComposantFactory;
import Carte.Carte;
import Interface.ICarte;
import Interface.IInfoCompte;
import Interface.IInfoJoueur;
import Interface.IListeDeCartes;
import Interface.IPaiement;

public class TestAppli {

	/*	@Test
		public void test() {
		
			/**IInfoCompte ic = ComposantFactory.createInfoCompte();
			ic.setIsConnected(true);
			
			IListeDeCartes coll = ComposantFactory.createCollection();
			
			ICarte dico =  ComposantFactory.createDico();
			
			for (String c : coll.listerCartesListe("toto", "coll")) {
				System.out.println(dico.infosCarte(c));
			}
		}
	*/
	@Test
	public void testDetruireCarte() {
		//ligne de vie
		IPaiement ip = ComposantFactory.createCPaiementBouchon();
		ICarte iCarte = ComposantFactory.createCCarteBouchon(); // retourné le nombre de joyau
		IInfoJoueur iInfoJoueur = ComposantFactory.createCInfoJoueurBouchon(ip, iCarte);
			
		ArrayList<String> collection = iInfoJoueur.getCollection(iInfoJoueur.getName());
	
		//le joueur clique sur la carte chat
		int prix=iCarte.getPrixVente(iCarte.getNomCarte());
		int soldeInitJoyau = iInfoJoueur.getNb_joyaux();
		
		ArrayList<String> retour = iInfoJoueur.destructionCarte(iInfoJoueur.getName(),iCarte.getNomCarte()); 
		assertTrue(retour.contains("true"));
		assertEquals(retour.get(0), Integer.toString(soldeInitJoyau + prix));
		assertFalse(collection.contains(iCarte.getNomCarte()));		
	}
	

	@Test
	public void testAcheterCarte() {
		ICarte iCarte = ComposantFactory.createCCarteBouchon(); // renvoie le prix de l'achat de la carte exemple prix d'achat 20
		IInfoJoueur iInfoJoueur = ComposantFactory.createCInfoJoueurBouchon(null, iCarte);// le joueur qu'on veut tester 
		
		// le bouchon contient une seule carte 
		// la fonction acheterCarte : 	appel la fonction ip.payer(iInfoJoueur.getName(),iCarte.listerCartes().get(0)); 
		int soldeInitJoyau = iInfoJoueur.getNb_joyaux();
		int soldeRestantJoyau = iInfoJoueur.acheterCarte(iCarte.getNomCarte());
				
		int prix = iCarte.getPrixAchat(iCarte.getNomCarte());
		

		assertEquals(soldeInitJoyau - prix, 17);
		
		// pour verifier que le carte a bien été ajouté a la collection 
		// le vrai teste c'est assertEquals(iInfoJoueur.getCollection(iInfoJoueur.getName()).contains(iCarte.getNomCarte()), true);
		// comme on a mis des valeurs a la con dans le bouchon, la carte voleuse ... a été supprimé  
		assertEquals(!iInfoJoueur.getCollection(iInfoJoueur.getName()).contains(iCarte.getNomCarte()), true);
	}
	
	
	@Test
	public void testAcheterEmplacementDeckPack() {
	    // Initialisation des lignes de vies
	    IInfoCompte infoCompte = ComposantFactory.createCInfoCompte();
	    IPaiement paiement = ComposantFactory.createCPaiement();
	    IInfoJoueur infoJoueur = ComposantFactory.createCInfoJoueur(paiement, null); //car pas de carte requise dans le diagramme de séquence
	
	    infoCompte.acheterEmplacementDeckPack();
	}
	
	
	@Test
	public void testAjouterCoordonneesBancaires() {
	
	}
	
	
	@Test
	public void testComposerDeck() {
	//ligne de vie
	IPaiement ip = ComposantFactory.createCPaiement();
	ICarte iCarte = ComposantFactory.createCCarte();
	IInfoJoueur iInfoJoueur = ComposantFactory.createCInfoJoueur(ip, iCarte);
	IListeDeCartes coll = ComposantFactory.createCListeDeCarte();
		
	for (String d : iInfoJoueur.listerDeckJoueur("Bob")) {
		System.out.println(d);
	}
	// le joueur choisit le deck D1
	for (String c : coll.listerCartesListe("Bob", "D1")) {
		System.out.println(c);
	}
		
	ArrayList<String> collection = iInfoJoueur.getCollection("Bob");
	for (String c : coll.listerCartesListe("Bob", "collection")) {
		System.out.println(c);
	}
		
	//le joueur clique sur la carte chat
	System.out.println(iCarte.infosCarte(new ArrayList<String>(Arrays.asList("chat"))).get(0));
	
	Boolean vide= coll.verificationDeckEmplacementVide("Bob","D1");
	if (vide) {
		for(String c : coll.ajouterCarteListe("Bob", "chat", "D1")){
			System.out.println(c);
		}
	}
	else System.out.println("Vous n'avez plus de place dans votre deck.");
	
	}
	
	

	
	@Test
	public void testInscription() {
	
	}
	
	
	@Test
	public void testJouer() {
	
	}
	
	
	@Test
	public void testSeConnecter() {

	}
	
	
	@Test
	public void testSeDeconnecter() {

	}
	
	
	@Test
	public void testOuvrirPack() {
	    // Initialisation des lignes de vies
	    IInfoCompte infoCompte = ComposantFactory.createCInfoCompte();
	    IInfoJoueur infoJoueur = ComposantFactory.createCInfoJoueur(null, null);
		IListeDeCartes coll = ComposantFactory.createCListeDeCarte();
	
	    String[] cartes = infoJoueur.ouvrirPack();
	    for (String carte: cartes) {
	    	assertTrue(carte == "");
	    }
	    
	    infoJoueur.donnerPack("Bob");
	    
	    cartes = infoJoueur.ouvrirPack();
	    ArrayList<String> collection = infoJoueur.getCollection("Bob");

	    for (String carte: cartes) {
	    	assertTrue(carte != "");
	    	// assertTrue(coll.listerCartesListe("Bob", collection).contains(carte));
	    }
	    
	}
}