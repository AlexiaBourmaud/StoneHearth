package Bouchons;

import java.util.Date;

import Interface.IInfoCompte;

public class CompteBouchon implements IInfoCompte {
	private static final String idJoueur = "marc";
	private static final String mdp = "azerty";
	private static boolean isConnected = true;
	
	@Override
	public Boolean estConnecte(String idJoueur, String mdp) {
		return isConnected;
	}

	@Override
	public Boolean acheterEmplacementDeckPack(String idJoueur, Boolean isPack) {
		return true;
	}

	@Override
	public Boolean enregistrerCB(String idJoueur, String nom, Integer numero,
			Date dateExpiration, String cvv) {
		// TODO Module de remplacement de méthode auto-généré
		return true;
	}

	@Override
	public Boolean enregistrerDonnees(String pseudo, String motDePasse) {
		// TODO Module de remplacement de méthode auto-généré
		return true;
	}

	@Override
	public String getCoordonneesBancaires(String idJoueur) {
		// TODO Module de remplacement de méthode auto-généré
		return null;
	}

	@Override
	public Boolean verifierPseudoMotDePasse(String idJoueur, String pass) {
		return true;
	}

	@Override
	public Boolean setIsConnected(String idJoueur, Boolean val) {
		// TODO Module de remplacement de méthode auto-généré
		return true;
	}

	@Override
	public Boolean getIsConnected(String idJoueur) {
		return isConnected;
	}

	@Override
	public Boolean disponiblePseudo(String pseudo) {
		return true;
	}

}
